#!C:\Python37\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'Transmitor==1.0','console_scripts','Transmitor'
__requires__ = 'Transmitor==1.0'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('Transmitor==1.0', 'console_scripts', 'Transmitor')()
    )
